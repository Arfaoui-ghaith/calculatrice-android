package com.example.calculatricearfaouighaith;

public class Calcul {
    public static String extract_Operation(String ch, int position){

        String ch1="";
        String ch2="";

        for(int i=(position+1); i<ch.length();i++){
            if( (ch.charAt(i) == '+') || ch.charAt(i)=='-' || ch.charAt(i)=='/' || ch.charAt(i)=='*'){
                break;
            }
            else{
                ch1=ch1+ch.charAt(i);

            }
        }

        for(int i=(position-1); i>-1;i--){
            if(ch.charAt(i)=='+' || ch.charAt(i)=='-' || ch.charAt(i)=='/' || ch.charAt(i)=='*'){
                break;
            }
            else{
                ch2=ch.charAt(i)+ch2;

            }
        }

        return ch2+ch.charAt(position)+ch1;
    }

    public static String sous_calcul(String ch){

        String c = "";

        for(int i=0; i<ch.length();i++){
            if( (ch.charAt(i) == '+') || ch.charAt(i)=='-' || ch.charAt(i)=='/' || ch.charAt(i)=='*'){
                c = c + ch.charAt(i); break;
            }
        }

        ch = ch.replace(c," ");
        String[] numbers = ch.split(" ");



        switch(c){
            case "*" : {
                if(numbers[0].indexOf(".") == -1 && numbers[1].indexOf(".") == -1 ){ return (Integer.parseInt(numbers[0]) * Integer.parseInt(numbers[1]))+""; }
                if(numbers[0].indexOf(".") != -1 && numbers[1].indexOf(".") != -1 ){ return (Double.parseDouble(numbers[0]) * Double.parseDouble(numbers[1]))+""; }
                if(numbers[0].indexOf(".") == -1 && numbers[1].indexOf(".") != -1 ){ return (Integer.parseInt(numbers[0]) * Double.parseDouble(numbers[1]))+""; }
                if(numbers[0].indexOf(".") != -1 && numbers[1].indexOf(".") == -1 ){ return (Double.parseDouble(numbers[0]) * Double.parseDouble(numbers[1]))+""; }
            };
            case "/" : {
                if(numbers[0].indexOf(".") == -1 && numbers[1].indexOf(".") == -1 ){ return (Integer.parseInt(numbers[0]) / Integer.parseInt(numbers[1]))+""; }
                if(numbers[0].indexOf(".") != -1 && numbers[1].indexOf(".") != -1 ){ return (Double.parseDouble(numbers[0]) / Double.parseDouble(numbers[1]))+""; }
                if(numbers[0].indexOf(".") == -1 && numbers[1].indexOf(".") != -1 ){ return (Integer.parseInt(numbers[0]) / Double.parseDouble(numbers[1]))+""; }
                if(numbers[0].indexOf(".") != -1 && numbers[1].indexOf(".") == -1 ){ return (Double.parseDouble(numbers[0]) / Double.parseDouble(numbers[1]))+""; }
            };
            case "+" : {
                if(numbers[0].indexOf(".") == -1 && numbers[1].indexOf(".") == -1 ){ return (Integer.parseInt(numbers[0]) + Integer.parseInt(numbers[1]))+""; }
                if(numbers[0].indexOf(".") != -1 && numbers[1].indexOf(".") != -1 ){ return (Double.parseDouble(numbers[0]) + Double.parseDouble(numbers[1]))+""; }
                if(numbers[0].indexOf(".") == -1 && numbers[1].indexOf(".") != -1 ){ return (Integer.parseInt(numbers[0]) + Double.parseDouble(numbers[1]))+""; }
                if(numbers[0].indexOf(".") != -1 && numbers[1].indexOf(".") == -1 ){ return (Double.parseDouble(numbers[0]) + Double.parseDouble(numbers[1]))+""; }
            };
            case "-" : {
                if(numbers[0].indexOf(".") == -1 && numbers[1].indexOf(".") == -1 ){ return (Integer.parseInt(numbers[0]) - Integer.parseInt(numbers[1]))+""; }
                if(numbers[0].indexOf(".") != -1 && numbers[1].indexOf(".") != -1 ){ return (Double.parseDouble(numbers[0]) - Double.parseDouble(numbers[1]))+""; }
                if(numbers[0].indexOf(".") == -1 && numbers[1].indexOf(".") != -1 ){ return (Integer.parseInt(numbers[0]) - Double.parseDouble(numbers[1]))+""; }
                if(numbers[0].indexOf(".") != -1 && numbers[1].indexOf(".") == -1 ){ return (Double.parseDouble(numbers[0]) - Double.parseDouble(numbers[1]))+""; }
            };
            default: return "";
        }
    }


    public static String calcul(String ch){
        String extract;
        String result;
        while(ch.indexOf("*") != -1){
            extract = extract_Operation(ch,ch.indexOf("*"));
            result = sous_calcul(extract);
            ch = ch.replace(extract,result);
        }

        while(ch.indexOf("/") != -1){
            extract = extract_Operation(ch,ch.indexOf("/"));
            result = sous_calcul(extract);
            ch = ch.replace(extract,result);
        }

        while(ch.indexOf("+") != -1){
            extract = extract_Operation(ch,ch.indexOf("+"));
            result = sous_calcul(extract);
            ch = ch.replace(extract,result);
        }

        while(ch.indexOf("-") != -1){
            extract = extract_Operation(ch,ch.indexOf("-"));
            result = sous_calcul(extract);
            ch = ch.replace(extract,result);
        }


        return ch;
    }
}
