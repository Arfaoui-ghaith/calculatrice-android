package com.example.calculatricearfaouighaith;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import com.example.calculatricearfaouighaith.Calcul;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Button b0 = findViewById(R.id.btn0);
        Button b1 = findViewById(R.id.btn1);
        Button b2 = findViewById(R.id.btn2);
        Button b3 = findViewById(R.id.btn3);
        Button b4 = findViewById(R.id.btn4);
        Button b5 = findViewById(R.id.btn5);
        Button b6 = findViewById(R.id.btn6);
        Button b7 = findViewById(R.id.btn7);
        Button b8 = findViewById(R.id.btn8);
        Button b9 = findViewById(R.id.btn9);
        Button point = findViewById(R.id.point1);

        Button multiple = findViewById(R.id.multiple);
        Button divise = findViewById(R.id.divise);
        Button plus = findViewById(R.id.plus);
        Button moin = findViewById(R.id.moin);
        Button egale = findViewById(R.id.egale);
        Button clear = findViewById(R.id.clear1);


        b0.setOnClickListener(this);
        b1.setOnClickListener(this);
        b2.setOnClickListener(this);
        b3.setOnClickListener(this);
        b4.setOnClickListener(this);
        b5.setOnClickListener(this);
        b6.setOnClickListener(this);
        b7.setOnClickListener(this);
        b8.setOnClickListener(this);
        b9.setOnClickListener(this);

        point.setOnClickListener( new View.OnClickListener(){
            @Override
            public void onClick(View v){
                TextView res = findViewById(R.id.res);
                res.setText(res.getText()+".");
            }
        });
        multiple.setOnClickListener( new View.OnClickListener(){
            @Override
            public void onClick(View v){
                TextView res = findViewById(R.id.res);
                int lastc = res.getText().length() - 1;
                if(res.getText().charAt(lastc) != '*' && res.getText().charAt(lastc) != '/' && res.getText().charAt(lastc) != '+' && res.getText().charAt(lastc) != '-') {
                    res.setText(res.getText() + "*");
                }
            }
        });
        divise.setOnClickListener( new View.OnClickListener(){
            @Override
            public void onClick(View v){
                TextView res = findViewById(R.id.res);
                int lastc = res.getText().length() - 1;
                if(res.getText().charAt(lastc) != '*' && res.getText().charAt(lastc) != '/' && res.getText().charAt(lastc) != '+' && res.getText().charAt(lastc) != '-') {
                res.setText(res.getText()+"/");
            }}
        });
        plus.setOnClickListener( new View.OnClickListener(){
            @Override
            public void onClick(View v){
                TextView res = findViewById(R.id.res);
                int lastc = res.getText().length() - 1;
                if(res.getText().charAt(lastc) != '*' && res.getText().charAt(lastc) != '/' && res.getText().charAt(lastc) != '+' && res.getText().charAt(lastc) != '-') {
                res.setText(res.getText()+"+");
            }}
        });
        moin.setOnClickListener( new View.OnClickListener(){
            @Override
            public void onClick(View v){
                TextView res = findViewById(R.id.res);
                int lastc = res.getText().length() - 1;
                if(res.getText().charAt(lastc) != '*' && res.getText().charAt(lastc) != '/' && res.getText().charAt(lastc) != '+' && res.getText().charAt(lastc) != '-') {
                res.setText(res.getText()+"-");
            }}
        });

        egale.setOnClickListener( new View.OnClickListener(){
           @Override
           public void onClick(View v){
               TextView res = findViewById(R.id.res);
               if(res.getText().toString().indexOf("=") == -1){
               String result = Calcul.calcul(res.getText().toString());
               res.setText(res.getText() + " = " + result);
           }
           }
        });

        clear.setOnClickListener( new View.OnClickListener(){
            @Override
            public void onClick(View v){
                TextView res = findViewById(R.id.res);
                res.setText("0");
            }
        });

    }

    @Override
    public void onClick(View v) {
        Button b = findViewById(v.getId());
        TextView res = findViewById(R.id.res);


            if (res.getText().charAt(0) == '0' && res.getText().length() == 1) {
                res.setText(b.getText());
            } else {
                res.setText(res.getText() + "" + b.getText());
            }

    }



}